#!/bash/python

# python /wynton/group/burchard/maka/data_shared/workflow.sh/pipeline/PredictDB_Pipeline_GTEx_v7/model_training/scripts/create_covariances_mod.py -d /wynton/group/burchard/maka/project/topmedp4.rnaseq/predictdb/run1/all.AA -p AA

# python test.py arg1 arg2 arg3

import gzip
import sqlite3
import os
import os.path
from os import path
import sys, getopt

argv = sys.argv[1:]
rundir = ''
prefix = ''
try:
  # use : if require an argument
  opts, args = getopt.getopt(argv,"hd:f:",["rundir=","prefix="])
except getopt.GetoptError:
    
  print('create_covariances_mod.py -d <rundir> -f <prefix>')
  sys.exit(2)
for opt, arg in opts:
  if opt == '-h':
     print('create_covariances_mod.py -d <rundir> -f <prefix>')
     sys.exit()
  elif opt in ("-d", "--rundir"):
     rundir = arg
  elif opt in ("-f", "--dbPrefix"):
     prefix = arg
  else:
     print("opt = ",opt)
print('rundir = ', rundir)
print('prefix = ', prefix)


tissues_ori = ['Adipose_Subcutaneous',
             'Adipose_Visceral_Omentum',
             'Adrenal_Gland',
             'Artery_Aorta',
             'Artery_Coronary',
             'Artery_Tibial',
             'Brain_Amygdala',
             'Brain_Anterior_cingulate_cortex_BA24',
             'Brain_Caudate_basal_ganglia',
             'Brain_Cerebellar_Hemisphere',
             'Brain_Cerebellum',
             'Brain_Cortex',
             'Brain_Frontal_Cortex_BA9',
             'Brain_Hippocampus',
             'Brain_Hypothalamus',
             'Brain_Nucleus_accumbens_basal_ganglia',
             'Brain_Putamen_basal_ganglia',
             'Brain_Spinal_cord_cervical_c-1',
             'Brain_Substantia_nigra',
             'Breast_Mammary_Tissue',
             'Cells_EBV-transformed_lymphocytes',
             'Cells_Transformed_fibroblasts',
             'Colon_Sigmoid',
             'Colon_Transverse',
             'Esophagus_Gastroesophageal_Junction',
             'Esophagus_Mucosa',
             'Esophagus_Muscularis',
             'Heart_Atrial_Appendage',
             'Heart_Left_Ventricle',
             'Liver',
             'Lung',
             'Minor_Salivary_Gland',
             'Muscle_Skeletal',
             'Nerve_Tibial',
             'Ovary',
             'Pancreas',
             'Pituitary',
             'Prostate',
             'Skin_Not_Sun_Exposed_Suprapubic',
             'Skin_Sun_Exposed_Lower_leg',
             'Small_Intestine_Terminal_Ileum',
             'Spleen',
             'Stomach',
             'Testis',
             'Thyroid',
             'Uterus',
             'Vagina',
             'Whole_Blood']
tissues = ['Whole_Blood']

if 1 == 0:
    rundir = "/wynton/group/burchard/maka/project/topmedp4.rnaseq/predictdb/run1/all.AA"
    prefix = "gala.sage.AA"

for tiss in tissues:
    print(tiss)
    # Get set of genes with significant models
    
    # $PREFIX_Whole_Blood_AA_tw_0.5_signif.db
    tiss = 'Whole_Blood'
    dbFp = rundir + '/model_training/dbs/' + prefix + '_' + tiss + '_tw_0.5_signif.db'
    print(dbFp)
    conn = sqlite3.connect(dbFp)
    c = conn.cursor()
    c.execute('select gene from extra')
    signif_genes = {row[0] for row in c.fetchall()}
    conn.close()
    
    # Whole_Blood_nested_cv_chr20_covariances.txt
    covOutFp = rundir + '/model_training/covariances/' + prefix + '_' + tiss + '_covariances.txt.gz'
    print(covOutFp)
    if (path.exists(covOutFp)):
        os.remove(covOutFp)
        print (covOutFp, "exists. Delete file.")
    with gzip.open(covOutFp, 'w') as cov_out:
        hdr = ' '.join(['GENE', 'RSID1', 'RSID2', 'VALUE']) + '\n'
        cov_out.write(hdr.encode('utf-8'))
        for chrom in range(1,23):
            covFp = rundir + '/model_training/covariances/' + tiss + '_nested_cv_chr' + str(chrom) + '_covariances.txt'
            print(covFp)
            with open(covFp) as cov_in:
                # Skip header
                line = cov_in.readline()
                for line in cov_in:
                    gene = line.strip().split()[0]
                    if gene in signif_genes:
                        cov_out.write((line.strip() +'\n').encode('utf-8')) 

