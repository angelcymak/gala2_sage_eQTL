argv <- commandArgs(trailingOnly = TRUE)
dummy <- argv[1]
outFI <- argv[2]
chrom <- argv[3]
snp_annot_file <- argv[4]
gene_annot_file <- argv[5]
genotype_file <- argv[6]
expression_file <- argv[7]
covariates_file <- argv[8]
rundir <- argv[9]
cov.cstr <- argv[10]
rFp <- argv[11]
general_rFp <- argv[12]

for (i in 1:length(argv)){
    cat(paste0(i," <- '",argv[i],"'\n"))
}

setwd(paste0(rundir,"/model_training/scripts/"))
source(rFp)
source(general_rFp)
"%&%" <- function(a,b) paste(a,b, sep='')

prefix <- outFI %&% "_nested_cv"

cat("Before chrom=",chrom,"\n")
main(snp_annot_file, gene_annot_file, genotype_file, expression_file, covariates_file, as.numeric(chrom), prefix, null_testing=FALSE, outdir=rundir,cov.cstr=cov.cstr)
