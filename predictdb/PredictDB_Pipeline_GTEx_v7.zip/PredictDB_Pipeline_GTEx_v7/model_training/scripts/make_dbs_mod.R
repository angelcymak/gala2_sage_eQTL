library(dplyr)
library(RSQLite)

args <- commandArgs(trailingOnly = TRUE)
pop <- args[1]
gene_annot_file <- args[2]
dir <- args[3]
prefix <- args[4]

if (prefix == ""){
    prefix <- "out"
}

for (i in 1:length(args)){
    cat(paste0(i," <- '",args[i],"'\n"))
}


dir.create(paste0(dir,"/dbs"), showWarnings = FALSE, recursive = TRUE, mode = "0755")

"%&%" <- function(a,b) paste(a,b, sep='')

tissues_ori <- c('Adipose_Subcutaneous',
             'Adipose_Visceral_Omentum',
             'Adrenal_Gland',
             'Artery_Aorta',
             'Artery_Coronary',
             'Artery_Tibial',
             'Brain_Amygdala',
             'Brain_Anterior_cingulate_cortex_BA24',
             'Brain_Caudate_basal_ganglia',
             'Brain_Cerebellar_Hemisphere',
             'Brain_Cerebellum',
             'Brain_Cortex',
             'Brain_Frontal_Cortex_BA9',
             'Brain_Hippocampus',
             'Brain_Hypothalamus',
             'Brain_Nucleus_accumbens_basal_ganglia',
             'Brain_Putamen_basal_ganglia',
             'Brain_Spinal_cord_cervical_c-1',
             'Brain_Substantia_nigra',
             'Breast_Mammary_Tissue',
             'Cells_EBV-transformed_lymphocytes',
             'Cells_Transformed_fibroblasts',
             'Colon_Sigmoid',
             'Colon_Transverse',
             'Esophagus_Gastroesophageal_Junction',
             'Esophagus_Mucosa',
             'Esophagus_Muscularis',
             'Heart_Atrial_Appendage',
             'Heart_Left_Ventricle',
             'Liver',
             'Lung',
             'Minor_Salivary_Gland',
             'Muscle_Skeletal',
             'Nerve_Tibial',
             'Ovary',
             'Pancreas',
             'Pituitary',
             'Prostate',
             'Skin_Not_Sun_Exposed_Suprapubic',
             'Skin_Sun_Exposed_Lower_leg',
             'Small_Intestine_Terminal_Ileum',
             'Spleen',
             'Stomach',
             'Testis',
             'Thyroid',
             'Uterus',
             'Vagina',
             'Whole_Blood'
)

tissues <- c('Whole_Blood')

driver <- dbDriver('SQLite')
gene_annot <- read.table(gene_annot_file, header = T, stringsAsFactors = F)

for (tiss in tissues) {
  print(tiss)
  # Extra table ----
  model_summaries <- read.table(dir %&% '/summary/' %&% tiss %&% '_nested_cv_chr1_model_summaries.txt', header = T, stringsAsFactors = F)
  tiss_summary <- read.table(dir %&% '/summary/' %&% tiss %&% '_nested_cv_chr1_tiss_chr_summary.txt', header = T, stringsAsFactors = F)
  
  n_samples <- tiss_summary$n_samples
  
  for (i in 2:22) {
    model_summaries <- rbind(model_summaries,
                             read.table(dir %&% '/summary/' %&% tiss %&% '_nested_cv_chr' %&% as.character(i) %&% '_model_summaries.txt', header = T, stringsAsFactors = F))
    tiss_summary <- rbind(tiss_summary,
                             read.table(dir %&% '/summary/' %&% tiss %&% '_nested_cv_chr' %&% as.character(i) %&% '_tiss_chr_summary.txt', header = T, stringsAsFactors = F))
  }
  
  model_summaries <- rename(model_summaries, gene = gene_id)

  conn <- dbConnect(drv = driver, dir %&% '/dbs/' %&% prefix %&% '_' %&% tiss %&% '_tw0.5.db')
  dbWriteTable(conn, 'model_summaries', model_summaries, overwrite = TRUE)
  dbGetQuery(conn, "CREATE INDEX gene_model_summary ON model_summaries (gene)")
  
  # Weights Table -----
  weights <- read.table(dir %&% '/weights/' %&% tiss %&% '_nested_cv_chr1_weights.txt', header = T, stringsAsFactors = F)
  for (i in 2:22) {
    weights <- rbind(weights,
                       read.table(dir %&% '/weights/' %&% tiss %&% '_nested_cv_chr' %&% as.character(i) %&% '_weights.txt', header = T, stringsAsFactors = F))
  }
  weights <- rename(weights, gene = gene_id)
  dbWriteTable(conn, 'weights', weights, overwrite = TRUE)
  dbGetQuery(conn, "CREATE INDEX weights_rsid ON weights (rsid)")
  dbGetQuery(conn, "CREATE INDEX weights_gene ON weights (gene)")
  dbGetQuery(conn, "CREATE INDEX weights_rsid_gene ON weights (rsid, gene)")
  
  # Sample_info Table ----
  sample_info <- data.frame(n_samples = n_samples, population = pop, tissue = tiss)
  dbWriteTable(conn, 'sample_info', sample_info, overwrite = TRUE)
  
  # Construction Table ----
  construction <- tiss_summary %>%
                    select(chrom, cv_seed) %>%
                    rename(chromosome = chrom)
  dbWriteTable(conn, 'construction', construction, overwrite = TRUE)
}
