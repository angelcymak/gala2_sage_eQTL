library(dplyr)
library(RSQLite)

args <- commandArgs(trailingOnly = TRUE)
dir <- args[1]
prefix <- args[2]

if (prefix == ""){
    prefix <- "out"
}

for (i in 1:length(args)){
    cat(paste0(i," <- '",args[i],"'\n"))
}


if (1 == 0){
    dir <- "/wynton/group/burchard/maka/project/topmedp4.rnaseq/predictdb/run1/all.AA/model_training"
    tissue <- "Whole_Blood"

}

"%&%" <- function(a,b) paste(a,b,sep='')

driver <- dbDriver("SQLite")



tissues_ori <- c('Adipose_Subcutaneous',
             'Adipose_Visceral_Omentum',
             'Adrenal_Gland',
             'Artery_Aorta',
             'Artery_Coronary',
             'Artery_Tibial',
             'Brain_Amygdala',
             'Brain_Anterior_cingulate_cortex_BA24',
             'Brain_Caudate_basal_ganglia',
             'Brain_Cerebellar_Hemisphere',
             'Brain_Cerebellum',
             'Brain_Cortex',
             'Brain_Frontal_Cortex_BA9',
             'Brain_Hippocampus',
             'Brain_Hypothalamus',
             'Brain_Nucleus_accumbens_basal_ganglia',
             'Brain_Putamen_basal_ganglia',
             'Brain_Spinal_cord_cervical_c-1',
             'Brain_Substantia_nigra',
             'Breast_Mammary_Tissue',
             'Cells_EBV-transformed_lymphocytes',
             'Cells_Transformed_fibroblasts',
             'Colon_Sigmoid',
             'Colon_Transverse',
             'Esophagus_Gastroesophageal_Junction',
             'Esophagus_Mucosa',
             'Esophagus_Muscularis',
             'Heart_Atrial_Appendage',
             'Heart_Left_Ventricle',
             'Liver',
             'Lung',
             'Minor_Salivary_Gland',
             'Muscle_Skeletal',
             'Nerve_Tibial',
             'Ovary',
             'Pancreas',
             'Pituitary',
             'Prostate',
             'Skin_Not_Sun_Exposed_Suprapubic',
             'Skin_Sun_Exposed_Lower_leg',
             'Small_Intestine_Terminal_Ileum',
             'Spleen',
             'Stomach',
             'Testis',
             'Thyroid',
             'Uterus',
             'Vagina',
             'Whole_Blood'
)

tissues <- c(
             'Whole_Blood'
)

for (tissue in tissues) {
  print(tissue)
  # input db
  unfiltered_db <- dir %&% "/dbs/" %&% prefix %&% "_" %&% tissue %&% "_tw0.5.db"
  # output db
  filtered_db <- dir %&% "/dbs/" %&% prefix %&% "_" %&% tissue %&% "_tw_0.5_signif.db"
  
  if (file.exists(filtered_db)) 
      file.remove(filtered_db)
  
  in_conn <- dbConnect(driver, unfiltered_db)
  out_conn <- dbConnect(driver, filtered_db)
  model_summaries <- dbGetQuery(in_conn, 'select * from model_summaries where zscore_pval < 0.05 and rho_avg > 0.1')
  nGenePass <- nrow(model_summaries)
  write(nGenePass,file=paste0(dir,"/dbs/z.nModelPass.txt"), append=T,sep="\t")
  model_summaries <- model_summaries %>% rename(pred.perf.R2 = rho_avg_squared, genename = gene_name, pred.perf.pval = zscore_pval, n.snps.in.model = n_snps_in_model)
  model_summaries$pred.perf.qval <- NA
  dbWriteTable(out_conn, 'extra', model_summaries)
  construction <- dbGetQuery(in_conn, 'select * from construction')
  # call dbDisconnect() when finished working with a connection 

  dbWriteTable(out_conn, 'construction', construction)
  sample_info <- dbGetQuery(in_conn, 'select * from sample_info')
  dbWriteTable(out_conn, 'sample_info', sample_info)
  
  weights <- dbGetQuery(in_conn, 'select * from weights')
  weights <- weights %>% filter(gene %in% model_summaries$gene) %>% rename(eff_allele = alt, ref_allele = ref, weight = beta)
  dbWriteTable(out_conn, 'weights', weights)
  
  # The following will generate warning
  # SQL statements must be issued with dbExecute() or dbSendStatement() instead of dbGetQuery() or dbSendQuery().
  dbGetQuery(out_conn, "CREATE INDEX weights_rsid ON weights (rsid)")
  dbGetQuery(out_conn, "CREATE INDEX weights_gene ON weights (gene)")
  dbGetQuery(out_conn, "CREATE INDEX weights_rsid_gene ON weights (rsid, gene)")
  dbGetQuery(out_conn, "CREATE INDEX gene_model_summary ON extra (gene)")
}
