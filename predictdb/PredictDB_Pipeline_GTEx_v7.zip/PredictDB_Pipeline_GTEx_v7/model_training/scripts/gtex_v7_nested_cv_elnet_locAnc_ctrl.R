suppressMessages(library(dplyr))
suppressMessages(library(glmnet))
suppressMessages((library(reshape2)))
suppressMessages(library(methods))
library(session)
"%&%" <- function(a,b) paste(a,b, sep = "")


get_filtered_snp_annot <- function(snp_annot_file_name) {
  snp_annot <- read.table(snp_annot_file_name, header = T, stringsAsFactors = F) %>%
    filter(!((ref_vcf == 'A' & alt_vcf == 'T') |
               (ref_vcf == 'T' & alt_vcf == 'A') |
               (ref_vcf == 'C' & alt_vcf == 'G') |
               (ref_vcf == 'G' & alt_vcf == 'C')) &
             !(is.na(rsid_dbSNP150))) %>%
    distinct(varID, .keep_all = TRUE)
  snp_annot
}


get_maf_filtered_genotype <- function(genotype_file_name,  maf, samples,logdir) {
  if (1 == 0){
    chrom <- 4
    gene_annot_file <- "prepare_data/expression/Homo_sapiens.GRCh38.85.genes.parsed.txt"
    gene_annot <- get_gene_annotation(gene_annot_file, chrom)
    
    expr_df <- get_gene_expression(expression_file, gene_annot)
    genotype_file_name <- "prepare_data/genotype/genotype.snp.4.txt"
    
    expression_file <- "prepare_data/expression/whole_blood_Analysis.expression.txt"
    expr_df <- read.table(expression_file,header=T)
    samples <- colnames(expr_df[,-1])
    maf <- 0.01
    
  }
  
  gt_df <- read.table(genotype_file_name, header = T, stringsAsFactors = F, row.names = 1)
  gt_df <- gt_df[,samples] %>% t() %>% as.data.frame()
  effect_allele_freqs <- colMeans(gt_df) / 2
  # saveRDS(effect_allele_freqs,file=paste0(logdir,"/r.effectA.rds"))
  cat("maf=",maf,"\n")
  gt_df <- gt_df[,which((effect_allele_freqs >= maf) & (effect_allele_freqs <= 1 - maf))]
  # saveRDS(gt_df,file=paste0(logdir,"/r.gt.rds"))
  gt_df
  
}

get_gene_annotation <- function(gene_annot_file_name, chrom, gene_types=c('protein_coding', 'pseudogene', 'lincRNA')){
  # gene_annot_file_name <- "prepare_data/expression/Homo_sapiens.GRCh38.85.genes.parsed.txt"
  gene_df <- read.table(gene_annot_file_name, header = TRUE, stringsAsFactors = FALSE) %>%
    filter((chr == chrom) & gene_type %in% gene_types)
  gene_df
}

get_gene_type <- function(gene_annot, gene) {
  filter(gene_annot, gene_id == gene)$gene_type
}

get_gene_expression <- function(gene_expression_file_name, gene_annot) {
  expr_df <- as.data.frame(t(read.table(gene_expression_file_name, header = T, stringsAsFactors = F, row.names = 1)))
  expr_df <- expr_df %>% select(one_of(intersect(gene_annot$gene_id, colnames(expr_df))))
  expr_df
}

get_gene_coords <- function(gene_annot, gene) {
  row <- gene_annot[which(gene_annot$gene_id == gene),]
  c(row$start, row$end)
}

get_cis_genotype <- function(gt_df, snp_annot, coords, cis_window) {
  snp_info <- snp_annot %>% filter((pos >= (coords[1] - cis_window) & !is.na(rsid_dbSNP150)) & (pos <= (coords[2] + cis_window)))
  if (nrow(snp_info) == 0)
    return(NA)
  cis_gt <- gt_df %>% select(one_of(intersect(snp_info$varID, colnames(gt_df))))
  column_labels <- colnames(cis_gt)
  row_labels <- rownames(cis_gt)
  # Convert cis_gt to a matrix for glmnet
  cis_gt <- matrix(as.matrix(cis_gt), ncol=ncol(cis_gt)) # R is such a bad language.
  colnames(cis_gt) <- column_labels
  rownames(cis_gt) <- row_labels
  cis_gt
}

get_covariates <- function(covariate_file_name, samples) {
  cov_df <- read.table(covariate_file_name, header = TRUE, stringsAsFactors = FALSE, row.names = 1)
  cov_df <- cov_df[,samples] %>% t() %>% as.data.frame()
  cov_df
}

generate_fold_ids <- function(n_samples, n_folds=10) {
  n <- ceiling(n_samples / n_folds)
  fold_ids <- rep(1:n_folds, n)
  sample(fold_ids[1:n_samples])
}

adjust_for_covariates <- function(expression_vec, cov_df) {
  combined_df <- cbind(expression_vec, cov_df)
  expr_resid <- summary(lm(expression_vec ~ ., data=combined_df))$residuals
  expr_resid <- scale(expr_resid, center = TRUE, scale = TRUE)
  expr_resid
}

calc_R2 <- function(y, y_pred) {
  tss <- sum(y**2)
  rss <- sum((y - y_pred)**2)
  1 - rss/tss
}

calc_corr <- function(y, y_pred) {
  sum(y*y_pred) / (sqrt(sum(y**2)) * sqrt(sum(y_pred**2)))
}

nested_cv_elastic_net_perf <- function(x, y, n_samples, n_train_test_folds, n_k_folds, alpha) {
  # Gets performance estimates for k-fold cross-validated elastic-net models.
  # Splits data into n_train_test_folds disjoint folds, roughly equal in size,
  # and for each fold, calculates a n_k_folds cross-validated elastic net model. Lambda parameter is
  # cross validated. Then get performance measures for how the model predicts on the hold-out
  # fold. Get the coefficient of determination, R^2, and a p-value, where the null hypothesis
  # is there is no correlation between prediction and observed.
  #
  # The mean and standard deviation of R^2 over all folds is then reported, and the p-values
  # are combined using Fisher's method.
  
  R2_folds <- rep(0, n_train_test_folds)
  corr_folds <- rep(0, n_train_test_folds)
  zscore_folds <- rep(0, n_train_test_folds)
  pval_folds <- rep(0, n_train_test_folds)
  # Outer-loop split into training and test set.
  train_test_fold_ids <- generate_fold_ids(n_samples, n_folds=n_train_test_folds)
  for (test_fold in 1:n_train_test_folds) {
    train_idxs <- which(train_test_fold_ids != test_fold)
    test_idxs <- which(train_test_fold_ids == test_fold)
    x_train <- x[train_idxs, ]
    y_train <- y[train_idxs]
    x_test <- x[test_idxs, ]
    y_test <- y[test_idxs]
    # Inner-loop - split up training set for cross-validation to choose lambda.
    cv_fold_ids <- generate_fold_ids(length(y_train), n_k_folds)
    thresh=1e-7
    
    y_pred <- tryCatch({
      # Fit model with training data.
      # fit <- cv.glmnet(x_train, y_train, nfolds = n_k_folds, alpha = alpha, type.measure='mse', foldid = cv_fold_ids, thresh=thresh, dfmax=670)
      
      fit <- cv.glmnet(x_train, y_train, nfolds = n_k_folds, alpha = alpha, type.measure='mse', foldid = cv_fold_ids, thresh=thresh)
      
      # Predict test data using model that had minimal mean-squared error in cross validation.
      predict(fit, x_test, s = 'lambda.min')},
      # if the elastic-net model did not converge, predict the mean of the y_train (same as all non-intercept coef=0)
      error = function(cond) rep(mean(y_train), length(y_test)))
    R2_folds[test_fold] <- calc_R2(y_test, y_pred)
    # Get p-value for correlation test between predicted y and actual y.
    # If there was no model, y_pred will have var=0, so cor.test will yield NA.
    # In that case, give a random number from uniform distribution, which is what would
    # usually happen under the null.
    corr_folds[test_fold] <- ifelse(sd(y_pred) != 0, cor(y_pred, y_test), 0)
    zscore_folds[test_fold] <- atanh(corr_folds[test_fold])*sqrt(length(y_test) - 3) # Fisher transformation
    pval_folds[test_fold] <- ifelse(sd(y_pred) != 0, cor.test(y_pred, y_test)$p.value, runif(1))
  }
  R2_avg <- mean(R2_folds)
  R2_sd <- sd(R2_folds)
  rho_avg <- mean(corr_folds)
  rho_se <- sd(corr_folds)
  rho_avg_squared <- rho_avg**2
  # Stouffer's method for combining z scores.
  zscore_est <- sum(zscore_folds) / sqrt(n_train_test_folds)
  zscore_pval <- 2*pnorm(abs(zscore_est), lower.tail = FALSE)
  # Fisher's method for combining p-values: https://en.wikipedia.org/wiki/Fisher%27s_method
  pval_est <- pchisq(-2 * sum(log(pval_folds)), 2*n_train_test_folds, lower.tail = F)
  list(R2_avg=R2_avg, R2_sd=R2_sd, pval_est=pval_est, rho_avg=rho_avg, rho_se=rho_se, rho_zscore=zscore_est, rho_avg_squared=rho_avg_squared, zscore_pval=zscore_pval,thresh=thresh)
}

nested_cv_elastic_net_perf2 <- function(x, y, n_samples, n_train_test_folds, n_k_folds, alpha, dfmax, pmax, thresh) {
  # Gets performance estimates for k-fold cross-validated elastic-net models.
  # Splits data into n_train_test_folds disjoint folds, roughly equal in size,
  # and for each fold, calculates a n_k_folds cross-validated elastic net model. Lambda parameter is
  # cross validated. Then get performance measures for how the model predicts on the hold-out
  # fold. Get the coefficient of determination, R^2, and a p-value, where the null hypothesis
  # is there is no correlation between prediction and observed.
  #
  # The mean and standard deviation of R^2 over all folds is then reported, and the p-values
  # are combined using Fisher's method.
  
  R2_folds <- rep(0, n_train_test_folds)
  corr_folds <- rep(0, n_train_test_folds)
  zscore_folds <- rep(0, n_train_test_folds)
  pval_folds <- rep(0, n_train_test_folds)
  # Outer-loop split into training and test set.
  train_test_fold_ids <- generate_fold_ids(n_samples, n_folds=n_train_test_folds)
  for (test_fold in 1:n_train_test_folds) {
    train_idxs <- which(train_test_fold_ids != test_fold)
    test_idxs <- which(train_test_fold_ids == test_fold)
    x_train <- x[train_idxs, ]
    y_train <- y[train_idxs]
    x_test <- x[test_idxs, ]
    y_test <- y[test_idxs]
    # Inner-loop - split up training set for cross-validation to choose lambda.
    cv_fold_ids <- generate_fold_ids(length(y_train), n_k_folds)
    y_pred <- tryCatch({
      # Fit model with training data.
      fit <- cv.glmnet(x_train, y_train, nfolds = n_k_folds, alpha = alpha, type.measure='mse', foldid = cv_fold_ids, dfmax=dfmax, pmax=pmax, thresh=thresh)
      # Predict test data using model that had minimal mean-squared error in cross validation.
      predict(fit, x_test, s = 'lambda.min')},
      # if the elastic-net model did not converge, predict the mean of the y_train (same as all non-intercept coef=0)
      error = function(cond) rep(mean(y_train), length(y_test)))
    R2_folds[test_fold] <- calc_R2(y_test, y_pred)
    # Get p-value for correlation test between predicted y and actual y.
    # If there was no model, y_pred will have var=0, so cor.test will yield NA.
    # In that case, give a random number from uniform distribution, which is what would
    # usually happen under the null.
    corr_folds[test_fold] <- ifelse(sd(y_pred) != 0, cor(y_pred, y_test), 0)
    zscore_folds[test_fold] <- atanh(corr_folds[test_fold])*sqrt(length(y_test) - 3) # Fisher transformation
    pval_folds[test_fold] <- ifelse(sd(y_pred) != 0, cor.test(y_pred, y_test)$p.value, runif(1))
  }
  R2_avg <- mean(R2_folds)
  R2_sd <- sd(R2_folds)
  rho_avg <- mean(corr_folds)
  rho_se <- sd(corr_folds)
  rho_avg_squared <- rho_avg**2
  # Stouffer's method for combining z scores.
  zscore_est <- sum(zscore_folds) / sqrt(n_train_test_folds)
  zscore_pval <- 2*pnorm(abs(zscore_est), lower.tail = FALSE)
  # Fisher's method for combining p-values: https://en.wikipedia.org/wiki/Fisher%27s_method
  pval_est <- pchisq(-2 * sum(log(pval_folds)), 2*n_train_test_folds, lower.tail = F)
  list(R2_avg=R2_avg, R2_sd=R2_sd, pval_est=pval_est, rho_avg=rho_avg, rho_se=rho_se, rho_zscore=zscore_est, rho_avg_squared=rho_avg_squared, zscore_pval=zscore_pval, dfmax=dfmax, pmax=pmax, thresh=thresh)
}

do_covariance <- function(gene_id, cis_gt, rsids, varIDs) {
  model_gt <- cis_gt[,varIDs, drop=FALSE]
  colnames(model_gt) <- rsids
  geno_cov <- cov(model_gt)
  geno_cov[lower.tri(geno_cov)] <- NA
  cov_df <- melt(geno_cov, varnames = c("rsid1", "rsid2"), na.rm = TRUE) %>%
              mutate(gene=gene_id) %>%
              select(GENE=gene, RSID1=rsid1, RSID2=rsid2, VALUE=value) %>%
              arrange(GENE, RSID1, RSID2)
  cov_df
}

main_locAnc <- function(snp_annot_file, gene_annot_file, genotype_file, expression_file,
                 covariates_file, chrom, prefix, maf=0.01, n_folds=10, n_train_test_folds=5,
                 seed=NA, cis_window=1e6, alpha=0.5, null_testing=FALSE, outdir, cov.cstr, covBaseFp) {
  # run2.4 : maf=0.05
  cat("chrom=",chrom,"\n")
  
  if ( 1 == 0 ){
   seed=NA; cis_window=1e6; alpha=0.5; null_testing=FALSE
   maf=0.01; n_folds=10; n_train_test_folds=5;
  }
  
  outdir2 <- paste0(outdir,"/model_training")
  logdir <- paste0(outdir,"/log")
  dir.create(logdir, showWarnings = FALSE, recursive = TRUE, mode = "0755")
  
  cat("Processing gene expression\n")
  gene_annot <- get_gene_annotation(gene_annot_file, chrom)
  expr_df <- get_gene_expression(expression_file, gene_annot)
  samples <- rownames(expr_df)
  n_samples <- length(samples)
  genes <- colnames(expr_df)
  n_genes <- length(expr_df)
  cat("nGenes=",n_genes,"\n")
  head(expr_df)
  snp_annot <- get_filtered_snp_annot(snp_annot_file)
  
  cat("Processing genotypes\n")
  gt_df <- get_maf_filtered_genotype(genotype_file, maf, samples, logdir)
  dim(gt_df)
  
  cat("Processing covariates\n")
  covariates_df <- get_covariates(covariates_file, samples)
  
  t.covBase <- read.table(gzfile(covBaseFp),header=T,sep="\t")
  covBase <- as.character(t.covBase[,1])
  
  print(covBase)
  
  print(covariates_df[1:5,1:5])
  
  colnames(covariates_df)
    cov.c <- unlist(strsplit(cov.cstr,":"))
    for (c in 1:ncol(covariates_df)){
        varname <- colnames(covariates_df)[c]
        if (!(varname %in% cov.c)){
            # cat("Convert to numeric:",varname,"\n")
            covariates_df[,c] <- as.numeric(covariates_df[,c])
        }
  }
  
   
  
  # Set seed----
  seed <- ifelse(is.na(seed), sample(1:1000000, 1), seed)
  set.seed(seed)
  
  # Prepare output data----
  model_summary_file <- outdir2 %&% '/summary/' %&% prefix %&% '_chr' %&% chrom %&% '_model_summaries.txt'
  run_summary_file <- outdir2 %&% '/summary/' %&% prefix %&% '_chr' %&% chrom %&% '_runInfo.txt'
  
  dir.create(paste0(outdir2,"/summary"), showWarnings = FALSE, recursive = TRUE, mode = "0755")
  
  if (file.exists(run_summary_file)) {
      #Delete file if it exists
      file.remove(run_summary_file)
  }
  
  model_summary_cols <- c('gene_id', 'gene_name', 'gene_type', 'alpha', 'n_snps_in_window', 'n_snps_in_model', 'lambda_min_mse',
                          'test_R2_avg', 'test_R2_sd', 'cv_R2_avg', 'cv_R2_sd', 'in_sample_R2',
                          'nested_cv_fisher_pval', 'rho_avg', 'rho_se', 'rho_zscore', 'rho_avg_squared', 'zscore_pval',
                          'cv_rho_avg', 'cv_rho_se', 'cv_rho_avg_squared', 'cv_zscore_est', 'cv_zscore_pval', 'cv_pval_est')
  write(model_summary_cols, file = model_summary_file, ncol = 24, sep = '\t')
  
  dir.create(paste0(outdir2,"/custom"), showWarnings = FALSE, recursive = TRUE, mode = "0755")
  adj_exp_fp <- outdir2 %&% '/custom/' %&% prefix %&% '_chr' %&% chrom %&% '_adj.exp.txt'
  pred_adj_exp_fp <- outdir2 %&% '/custom/' %&% prefix %&% '_chr' %&% chrom %&% '_pred.adj.exp.txt'
  file.create(adj_exp_fp,overwrite=T)
  file.create(pred_adj_exp_fp,overwrite=T)
  lm_fp <- outdir2 %&% '/custom/' %&% prefix %&% '_chr' %&% chrom %&% '_lm.pdf'
  pdf(lm_fp)
  
  weights_file <- outdir2 %&% '/weights/' %&% prefix %&% '_chr' %&% chrom %&% '_weights.txt'
  dir.create(paste0(outdir2,"/weights"), showWarnings = FALSE, recursive = TRUE, mode = "0755")
  weights_col <- c('gene_id', 'rsid', 'varID', 'ref', 'alt', 'beta')
  write(weights_col, file = weights_file, ncol = 6, sep = '\t')
  
  tiss_chr_summ_f <- outdir2 %&% '/summary/' %&% prefix %&% '_chr' %&% chrom %&% '_tiss_chr_summary.txt'
  
  tiss_chr_summ_col <- c('n_samples', 'chrom', 'cv_seed', 'n_genes')
  tiss_chr_summ <- data.frame(n_samples, chrom, seed, n_genes)
  colnames(tiss_chr_summ) <- tiss_chr_summ_col
  write.table(tiss_chr_summ, file = tiss_chr_summ_f, quote = FALSE, row.names = FALSE, sep = '\t')
  
  covariance_file <- outdir2 %&% '/covariances/' %&% prefix %&% '_chr' %&% chrom %&% '_covariances.txt'
  dir.create(paste0(outdir2,"/covariances"), showWarnings = FALSE, recursive = TRUE, mode = "0755")
  covariance_col <- c('GENE', 'RSID1', 'RSID2', 'VALUE')
  write(covariance_col, file = covariance_file, ncol = 4, sep = ' ')
  
  # save.session(paste0(logdir,"/r.RDa"))
  
  # Attempt to build model for each gene----
  if (n_genes > 0){
      for (i in 1:n_genes) {
        ptm <- proc.time()
        
        # geneid
        gene <- genes[i]
        gene_name <- gene_annot$gene_name[gene_annot$gene_id == gene]
        gene_type <- get_gene_type(gene_annot, gene)
        coords <- get_gene_coords(gene_annot, gene)
        cis_gt <- get_cis_genotype(gt_df, snp_annot, coords, cis_window)
        
        cat("\n\n",i, "/", n_genes, gene, gene_name, gene_type, "\n")
        
        lanc1 <- paste0(gene,".1")
        
        if (all(is.na(cis_gt))) {
          # No snps within window for gene.
          model_summary <- c(gene, gene_name, gene_type, alpha, 0, 0, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA)
          write(model_summary, file = model_summary_file, append = TRUE, ncol = 24, sep = '\t')
          next
        }
        model_summary <- c(gene, gene_name, gene_type, alpha, ncol(cis_gt), 0, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA)
        run_status <- "not_run"
        if (ncol(cis_gt) >= 2 & lanc1 %in% colnames(covariates_df)) {
          run_status <- "run:0"
          expression_vec <- expr_df[,i]
          
          # covName: covaraites + local ancestry
          # covName <- c(covBase, paste0(gene,".1"),paste0(gene,".2"))
          
          covName <- c(covBase)
          print(covName)
          
          adj_expression <- adjust_for_covariates(expression_vec, covariates_df[, covName])
          if (null_testing)
            adj_expression <- sample(adj_expression)
            
          cat("nested_cv_elastic_net_perf\n")
          perf_measures <- nested_cv_elastic_net_perf(cis_gt, adj_expression, n_samples, n_train_test_folds, n_folds, alpha)
          R2_avg <- perf_measures$R2_avg
          R2_sd <- perf_measures$R2_sd
          pval_est <- perf_measures$pval_est
          rho_avg <- perf_measures$rho_avg
          rho_se <- perf_measures$rho_se
          rho_zscore <- perf_measures$rho_zscore
          rho_avg_squared <- perf_measures$rho_avg_squared
          zscore_pval <- perf_measures$zscore_pval
          thresh <- perf_measures$thresh
          cat("thresh=",thresh,"\n")
          
          
          # Fit on all data
          # cv.glmnet : https://www.rdocumentation.org/packages/glmnet/versions/4.0-2/topics/cv.glmnet
          
          cv_fold_ids <- generate_fold_ids(length(adj_expression), n_folds)
          cat("glmnet\n")
          fit <- tryCatch(cv.glmnet(cis_gt, adj_expression, nfolds = n_folds, alpha = 0.5, type.measure='mse', foldid = cv_fold_ids, keep = TRUE, thresh=thresh), error = function(cond) {message('Error'); message(geterrmessage()); list()})
          cat("checkpoint 1\n")
          length(fit)
          if (length(fit) > 0) {
            run_status <- "run:1_fitY"
            cv_R2_folds <- rep(0, n_folds)
            cv_corr_folds <- rep(0, n_folds)
            cv_zscore_folds <- rep(0, n_folds)
            cv_pval_folds <- rep(0, n_folds)
            cat("checkpoint 2\n")
            best_lam_ind <- which.min(fit$cvm)
            for (j in 1:n_folds) {
              fold_idxs <- which(cv_fold_ids == j)
              adj_expr_fold_pred <- fit$fit.preval[fold_idxs, best_lam_ind]
              cv_R2_folds[j] <- calc_R2(adj_expression[fold_idxs], adj_expr_fold_pred)
              cv_corr_folds[j] <- ifelse(sd(adj_expr_fold_pred) != 0, cor(adj_expr_fold_pred, adj_expression[fold_idxs]), 0)
              cv_zscore_folds[j] <- atanh(cv_corr_folds[j])*sqrt(length(adj_expression[fold_idxs]) - 3) # Fisher transformation
              cv_pval_folds[j] <- ifelse(sd(adj_expr_fold_pred) != 0, cor.test(adj_expr_fold_pred, adj_expression[fold_idxs])$p.value, runif(1))
            }
            cv_R2_avg <- mean(cv_R2_folds)
            cv_R2_sd <- sd(cv_R2_folds)
            adj_expr_pred <- predict(fit, as.matrix(cis_gt), s = 'lambda.min')
            training_R2 <- calc_R2(adj_expression, adj_expr_pred)
            
            cv_rho_avg <- mean(cv_corr_folds)
            cv_rho_se <- sd(cv_corr_folds)
            cv_rho_avg_squared <- cv_rho_avg**2
            # Stouffer's method for combining z scores.
            cv_zscore_est <- sum(cv_zscore_folds) / sqrt(n_folds)
            cv_zscore_pval <- 2*pnorm(abs(cv_zscore_est), lower.tail = FALSE)
            cv_pval_est <- pchisq(-2 * sum(log(cv_pval_folds)), 2*n_folds, lower.tail = F)
            cat("    checkpoint 3:nzero",fit$nzero[best_lam_ind],"\n")
            
            if (fit$nzero[best_lam_ind] > 0) {
                run_status <- "run:2_best_lam_indY"
              
                weights <- fit$glmnet.fit$beta[which(fit$glmnet.fit$beta[,best_lam_ind] != 0), best_lam_ind]
                
                weighted_snps <- names(fit$glmnet.fit$beta[,best_lam_ind])[which(fit$glmnet.fit$beta[,best_lam_ind] != 0)]
                
                weighted_snps_info <- snp_annot %>% filter(varID %in% weighted_snps) %>% select(rsid_dbSNP150, varID, ref_vcf, alt_vcf)
                weighted_snps_info$gene <- gene
                weighted_snps_info <- weighted_snps_info %>%
                  merge(data.frame(weights = weights, varID=weighted_snps), by = 'varID') %>%
                  select(gene, rsid_dbSNP150, varID, ref_vcf, alt_vcf, weights)
                
                write.table(weighted_snps_info, file = weights_file, append = TRUE, quote = FALSE, col.names = FALSE, row.names = FALSE, sep = '\t')
                covariance_df <- do_covariance(gene, cis_gt, weighted_snps_info$rsid_dbSNP150, weighted_snps_info$varID)
                write.table(covariance_df, file = covariance_file, append = TRUE, quote = FALSE, col.names = FALSE, row.names = FALSE, sep = " ")
                
                # R2_avg, R2_sd, pval_est, rho_avg, rho_se, rho_zscore, rho_avg_squared, zscore_pval : nested cv, % variance explained
                  
                # cv_R2_avg, cv_R2_sd, cv_* : current CV
                
                # training_R2 = in_sample_R2
                
                model_summary <- c(gene, gene_name, gene_type, alpha, ncol(cis_gt), 
                                fit$nzero[best_lam_ind], fit$lambda[best_lam_ind], 
                                R2_avg, R2_sd, cv_R2_avg, cv_R2_sd, 
                                training_R2, pval_est,
                                rho_avg, rho_se, rho_zscore, rho_avg_squared, zscore_pval, 
                                cv_rho_avg, cv_rho_se, cv_rho_avg_squared, cv_zscore_est, cv_zscore_pval, cv_pval_est)
              
                cat("    checkpoint 4\n")
              
                t.lm <- data.frame(adj.exp=adj_expression[,1], cis_gt[names(adj_expression[,1]),weighted_snps])
                cat("    checkpoint 4A\n")
                
                lm.obj <- lm(data=t.lm, adj.exp~.)
                summary(lm.obj)
                cat("    checkpoint 4B\n")
                
                t.plot <- data.frame(exp=expression_vec, adj.exp=adj_expression[,1], pred.adj.exp.lm=lm.obj$fitted, pred.adj.exp=adj_expr_pred[names(adj_expression[,1]),1])
                cat("    checkpoint 4C\n")
                
                write(c(gene,gene_name,t.plot$adj.exp), file=adj_exp_fp, ncol=length(t.plot$adj.exp),sep="\t",append=T)
                
                write(c(gene,gene_name,t.plot$pred.adj.exp), file=pred_adj_exp_fp, ncol=length(t.plot$pred.adj.exp),sep="\t",append=T)
                cat("    checkpoint 4D\n")
                
                if (1 == 0 ){
                    for (i.plot in 1:6){
                        print(plot(lm.obj,i.plot))
                    }
                
                    r.obj <- NULL
                    r.obj <- cor.test(t.plot$adj.exp,t.plot$pred.adj.exp)
                    r <- NULL
                    r <- formatC(r.obj$estimate,format='g',digit=3)
                    p <- NULL
                    p <- formatC(r.obj$p.value,format='g',digit=3)
                    plot <- baseplot
                    plot <- plot + theme(axis.text.x = element_text(angle=45, hjust =1))
                    plot <- plot + geom_point(data=t.plot, aes(x=adj.exp, y=pred.adj.exp))
                    plot <- plot + labs(title=paste0(gene," | ",gene_name," | r=",r," | p=",p," | ",chrom,":",coords[1],"-",coords[2]))
                    plot <- plot + geom_smooth(method=lm,data=t.plot,aes(x=adj.exp,y=pred.adj.exp))
                    print(plot)
                }
                cat("    checkpoint 5\n")
            } else {
              run_status <- "run:2_best_lam_indN"
              model_summary <- c(gene, gene_name, gene_type, alpha, ncol(cis_gt), 0, fit$lambda[best_lam_ind], R2_avg, R2_sd,
                                 cv_R2_avg, cv_R2_sd, training_R2, pval_est, rho_avg, rho_se, rho_zscore, rho_avg_squared, zscore_pval,
                                 cv_rho_avg, cv_rho_se, cv_rho_avg_squared, cv_zscore_est, cv_zscore_pval, cv_pval_est)
            }
          } else {
            run_status <- "run:1_fitN"
            model_summary <- c(gene, gene_name, gene_type, alpha, ncol(cis_gt), 0, NA, R2_avg, R2_sd, NA, NA, NA, pval_est, rho_avg, rho_se, rho_zscore, rho_avg_squared, zscore_pval,
                               NA, NA, NA, NA, NA, NA)
          }
        }
        write(model_summary, file = model_summary_file, append = TRUE, ncol = length(model_summary), sep = '\t')
        
        v.out <- c(gene,gene_name,run_status)
        write(v.out, file=run_summary_file, ncol=length(v.out), sep="\t", append=T)
        
        cat("    checkpoint 6\n")
        print(proc.time() - ptm)
      
      # for (i in 1:n_genes) {
      }
  }else{
    cat("No genes found\n")
  }
  dev.off()
}
